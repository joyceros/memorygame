import {Component, OnInit} from '@angular/core';
import {Highscore} from '../highscore';

@Component({
  selector: 'app-highscores',
  templateUrl: './highscores.component.html',
  styleUrls: ['./highscores.component.css']
})
export class HighscoresComponent implements OnInit {

  list: Highscore[] = [];
  sort = false;

  constructor() {
  }

  ngOnInit(): void {
    this.list.push( new Highscore('joyce', 85));
    this.list.push( new Highscore('hans', 99));
    this.list.push( new Highscore('piet', 97));
    this.sortList();
  }

  sortList() {
    this.list.sort(this.compare);
    this.sort = true;
  }

  compare(a, b) {
    if (a.score < b.score) {
      return 1;
    }
    if (b.score < a.score) {
      return -1;
    }
    return 0;
  }

  add(name, score) {
    this.list.push(new Highscore(name, score));
    this.sortList();
  }
}
