export class Card {
  id: string;
  desc: string;
  show: string;
  done: boolean;

  constructor(id: string, desc: string) {
    this.id = id;
    this.desc = desc;
    this.show = '../../assets/memorycard.jpg';
    this.done = false;
  }
}
