import {Component, OnInit} from '@angular/core';
import {CardComponent} from './card/card.component';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Player} from './player';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'nieuwproject';
  component: CardComponent;
  reactiveForm: FormGroup;
  currentplayer: Player;
  showGame: boolean;
  showScores = false;
  endTime: number;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.createForm();
    this.showGame = false;
  }

  createForm() {
    this.reactiveForm = this.fb.group({
      player: ['', Validators.required]
    });
  }

  get player() {
    return this.reactiveForm.get('player').value;
  }

  newGame() {
    this.showGame = true;
    this.currentplayer = this.player;
    this.component = new CardComponent();
  }
}
