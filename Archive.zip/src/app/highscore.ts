export class Highscore {
  id: string;
  score: number;

  constructor(id: string, score: number) {
    this.id = id;
    this.score = score;
  }
}
