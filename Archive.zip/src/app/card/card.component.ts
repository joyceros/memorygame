import {Component, Input, OnInit} from '@angular/core';
import {Card} from '../card';
import {TimerComponent} from '../timer/timer.component';
import {HighscoresComponent} from '../highscores/highscores.component';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  @Input() playername;
  allPlayers: { playername };
  winningPlayer;
  selectedCard: Card;
  numbersDone = [];
  cards = [];
  playCards = 6;
  cardsLength = 10;
  allCards: Card[] = [
    new Card('1', 'lettera'), new Card('2', 'lettera'), new Card('3', 'letterb'),
    new Card('4', 'letterb'), new Card('5', 'letterc'), new Card('6', 'letterc'),
    new Card('7', 'letterd'), new Card('8', 'letterd'), new Card('9', 'lettere'),
    new Card('10', 'lettere')];
  rangeCards = [];
  mockedCards = [];
  card1 = new Card('', '');
  card2 = new Card('', '');
  timer: TimerComponent;
  goodMessage;
  highscores = new HighscoresComponent;

  onSelect(card: Card): void {
    if (this.card1.desc === '' && card.done === false) { // if this is the 1st card clicked
      this.card1 = card;
      card.show = '../../assets/' + card.id + '.jpg';
      card.done = true;
    } else if (card.done === false) {                   // if this is the 2nd card clicked
      this.card2 = card;
      const index = this.getIndex(this.card1.id);
      card.show = '../../assets/' + card.id + '.jpg';
      if (this.card1.desc === this.card2.desc) {        // if these cards have the same description
        card.done = true;
        this.cards[index].done = true;
        this.goodMessage = true;
        if (this.checkIfDone) {
          this.timer.stopTimer();
          console.log(this.playername);
          this.highscores.ngOnInit();
          this.highscores.add(this.playername, 10);
          console.log(this.highscores.list);
        }
      } else {                                         // if these cards don't have the same description
        this.cards[index].done = false;
        card.done = false;
        this.goodMessage = false;
        setTimeout(() => {
          this.cards[index].show = '../../assets/memorycard.jpg';
          card.show = '../../assets/memorycard.jpg';
        }, 1000);
      }
      this.card1 = new Card('', '');
      this.card2 = new Card('', '');
    }
  }

  selectCards() {
    let lastCard = Math.floor(Math.random() * this.cardsLength) + this.playCards;
    while (lastCard > this.cardsLength || lastCard % 2 === 1 || lastCard < this.playCards) {
      // tslint:disable-next-line:max-line-length
      lastCard = Math.floor(Math.random() * (this.cardsLength)) + this.playCards;
    }
    const s = lastCard - this.playCards;
    this.getCards(s, lastCard);
  }

  getCards(s, l) {
    this.rangeCards = [];
    for (let i = 0; i < this.allCards.length; i++) {
      if (i >= s && i < l) {
        this.rangeCards.push(new Card(this.allCards[i].id, this.allCards[i].desc));
      }
    }
    this.shuffle(this.setUpCards(this.rangeCards));
  }

  setUpCards(data) {
    for (let i = 0; i < this.playCards; i++) {
      this.mockedCards.push(new Card(data[i].id, data[i].desc));
    }
    return this.mockedCards;
  }

  shuffle(array) {
    this.numbersDone = [];
    this.cards = [];
    for (let x = 0; x < this.playCards; x++) {
      let random = Math.floor(Math.random() * array.length);
      while (this.numbersDone.includes(random)) {
        random = Math.floor(Math.random() * array.length);
      }
      this.numbersDone.push(random);
      this.cards.push(array[random]);
    }
  }

  get cardsList() {
    return this.cards;
  }

  ngOnInit(): void {
    this.timer = new TimerComponent();
    this.timer.startTimer();
    this.selectCards();
  }

  getIndex(id) {
    for (let i = 0; i < this.cards.length; i++) {
      if (this.cards[i].id === id) {
        return i;
      }
    }
  }

  get checkIfDone() {
    for (let i = 0; i < this.cards.length; i++) {
      if (this.cards[i].done === false) {
        return false;
      }
    }
    return true;
  }
}
