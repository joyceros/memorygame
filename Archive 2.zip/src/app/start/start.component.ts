import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {GameService} from '../services/game.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css']
})
export class StartComponent implements OnInit {

  reactiveForm: FormGroup;

  constructor(private fb: FormBuilder, private gameService: GameService, private router: Router) {
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.reactiveForm = this.fb.group({
      player: ['', Validators.required]
    });
  }

  startGame() {
    this.gameService.setPlayer(this.reactiveForm.get('player').value);
    this.router.navigateByUrl('/game');

  }
}
