import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {AppComponent} from './app.component';
import {CardComponent} from './card/card.component';
import {ReactiveFormsModule} from '@angular/forms';
import {TimerComponent} from './timer/timer.component';
import {HighscoresComponent} from './highscores/highscores.component';
import {HttpClientModule} from '@angular/common/http';
import {GameComponent} from './game/game.component';
import {StartComponent} from './start/start.component';
import { ConfigComponent } from './config/config.component';

const appRoutes: Routes = [
  {path: 'start', component: StartComponent},
  {path: 'game', component: GameComponent},
  {path: 'scores', component: HighscoresComponent},
  {path: '', redirectTo: '/start', pathMatch: 'full'},
  {path: 'show', component: ConfigComponent},
  // {path: 'api', }
];

@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    TimerComponent,
    HighscoresComponent,
    GameComponent,
    StartComponent,
    ConfigComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(
      appRoutes
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
