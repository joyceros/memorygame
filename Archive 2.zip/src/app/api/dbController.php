<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

class dbController
{
//$user = "eu191536";
//$pass = "eojYRTZW";
//$dbname = "eu191536_levelgegevens";

  public function getlink()
  {
    $user = 'root';
    $pass = '123456';
    $dbname = "memory";
    $link = mysqli_connect('localhost', $user, $pass, $dbname);
    if (mysqli_connect_error()) { //test the link if it doesnt work stop
      die(mysqli_connect_error());
    } else {
      return $link;
    }
  }
}

if (isset($_POST["functionname"]) || isset($_GET["functionname"])) {
  if (isset($_POST["functionname"])) {
    $functionname = $_POST["functionname"];

  } else if (isset($_GET["functionname"])) {
    $functionname = $_GET["functionname"];
  }
  switch ($functionname) {
    case 'get':
    {
      include './model/getdata.php';
      $endresult = json_encode($result);
      break;
    }
    case 'check':
    {
      include './model/checkcards.php';
      $endresult = $result;
      break;
    }
    case 'add':
    {
      include './model/addhighscore.php';
      $endresult = json_encode($result);
      break;
    }

    case 'gethigh':
    {
      include './model/gethighscores.php';
      $endresult = json_encode($result);
      break;
    }
  }
  echo $endresult;
}
