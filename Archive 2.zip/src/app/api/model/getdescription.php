<?php
function getdescription($id)
{
  $link = (new dbController)->getlink();
  mysqli_real_escape_string($link, $id);

  $sql1 = "SELECT * FROM cards WHERE ID = " . $id;
  $result1 = $link->query($sql1);
  $return_arr = array();
  if ($result1 == mysqli_query($link, $sql1)) {
    while ($row = mysqli_fetch_assoc($result1)) {
      $row_array['description'] = $row['description'];

      array_push($return_arr, $row_array);
    }
  }

  $return = $return_arr[0];
  return $return['description'];
}
