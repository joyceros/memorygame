<?php
include 'getdescription.php';

if (isset($_POST["c1"]) & isset($_POST["c2"])) {
  $result = "";
  $id = $_POST["c1"];
  $cardid = $_POST["c2"];
  $carddescription = getdescription($id);
  $link = (new dbController)->getlink();

  mysqli_real_escape_string($link, $cardid);
  mysqli_real_escape_string($link, $carddescription);

  $sql = "SELECT * FROM cards WHERE description ='" . $carddescription . "' AND ID != " . $id;
  $result = $link->query($sql);
  $result2 = mysqli_fetch_assoc($result);

  if (json_encode($result2['id']) === json_encode($cardid)) {
    $result = "true";
  } else {
    $result = "false";
  }

} else echo "Could not compare the two cards";
