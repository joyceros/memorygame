<?php

$sql = "SELECT * FROM highscores ORDER BY score DESC LIMIT 10";
$link = (new dbController)->getlink();
$return_arr = array();

//get the information from db
if ($result = mysqli_query($link, $sql)) {
  while ($row = mysqli_fetch_assoc($result)) {
    $row_array['name'] = $row['name'];
    $row_array['percentage'] = $row['percentage'];
    $row_array['time'] = $row['time'];
    $row_array['score'] = $row['score'];

    array_push($return_arr, $row_array);
  }
}
$result = $return_arr;

