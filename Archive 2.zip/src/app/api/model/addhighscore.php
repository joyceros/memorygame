<?php
$name = $_POST['name'];
$p = $_POST['percentage'];
$t = $_POST['time'];
$s = $_POST['score'];
$link = (new dbController)->getlink();
mysqli_real_escape_string($link, $name);
mysqli_real_escape_string($link, $p);
mysqli_real_escape_string($link, $t);
mysqli_real_escape_string($link, $s);

$sql = "INSERT INTO highscores (name, percentage, time, score) VALUES ('" . $name . "', " . $p . ", " . $t . ", " . $s . ")";

$result = $link->query($sql);
