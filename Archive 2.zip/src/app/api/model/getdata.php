<?php

if (isset($_POST["id1"]) & isset($_POST["id2"])) {
  $id1 = $_POST["id1"];
  $id2 = $_POST["id2"];
  $link = (new dbController)->getlink();
  mysqli_real_escape_string($link, $id1);
  mysqli_real_escape_string($link, $id2);

  $sql = "SELECT * FROM cards WHERE ID > " . $id1 . " AND ID <= " . $id2;
  $link->query($sql);

  $return_arr = array();
  if ($result = mysqli_query($link, $sql)) {
    while ($row = mysqli_fetch_assoc($result)) {
      $row_array['name'] = $row['id'];
      $row_array['description'] = $row['description'];
      $row_array['done'] = $row['done'];

      array_push($return_arr, $row_array);
    }
  }
  $result = $return_arr;
} else echo "Could not select these cards";
