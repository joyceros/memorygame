import {Component, OnInit, ViewChild} from '@angular/core';
import {Card} from '../entities/card';
import {TimerComponent} from '../timer/timer.component';
import {HighscoreService} from '../services/highscore.service';
import {CardComponent} from '../card/card.component';
import {GameService} from '../services/game.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {
  @ViewChild(TimerComponent) timer: TimerComponent;

  component: CardComponent;
  currentplayer: string;
  showGame: boolean;
  selectedCard: Card;
  card1 = new Card('', '');
  card2 = new Card('', '');
  cards = [];
  currentMessage: string;

  constructor(private highscoreService: HighscoreService, private gameService: GameService, private router: Router) {
  }

  get cardsList() {
    return this.cards;
  }

  get checkIfDone() {
    for (let i = 0; i < this.cards.length; i++) {
      if (this.cards[i].done === false) {
        return false;
      }
    }
    return true;
  }

  get getScore() {
    let good = 0;
    for (let i = 0; i < this.cards.length; i++) {
      if (this.cards[i].done === true) {
        good += 1;
      }
    }
    return good + this.timer.timeLeft;
  }

  addScore() {
    const score = this.getScore;
    this.highscoreService.addHighscore(this.currentplayer, score);
  }

  onSelect(card: Card): void {
    if (this.timer.timeLeft !== 0) {
      if (this.card1.desc === '' && card.done === false) { // if this is the 1st card clicked
        this.card1 = card;
        card.show = true;
        card.done = true;
      } else if (card.done === false) {                   // if this is the 2nd card clicked
        this.card2 = card;
        const index = this.getIndex(this.card1.id);
        card.show = true;
        if (this.card1.desc === this.card2.desc) {        // if these cards have the same description
          card.done = true;
          this.cards[index].done = true;
          this.currentMessage = 'good';
          if (this.checkIfDone) {
            this.timer.stopTimer();
          }
        } else {                                         // if these cards don't have the same description
          this.cards[index].done = false;
          card.done = false;
          this.currentMessage = 'wrong';
          setTimeout(() => {
            this.cards[index].show = false;
            card.show = false;
          }, 1000);
        }
        this.card1 = new Card('', '');
        this.card2 = new Card('', '');
      }
    } else {
      this.currentMessage = 'timesup';
    }
  }

  getIndex(id) {
    for (let i = 0; i < this.cards.length; i++) {
      if (this.cards[i].id === id) {
        return i;
      }
    }
  }

  ngOnInit(): void {
    this.currentplayer = this.gameService.getPlayer();
    if (this.currentplayer === '' || this.currentplayer === undefined) {
      this.router.navigateByUrl('/start');
    } else {
      this.showGame = true;
      this.cards = this.gameService.getCardsList();
    }
  }
}
