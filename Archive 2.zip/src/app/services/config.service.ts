import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {Highscore} from '../entities/highscore';
import {catchError, map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  configUrl = 'http://angular/api';
  highscores: Highscore[];

  constructor(private http: HttpClient) {
  }

  getAll(): Observable<Highscore[]> {
    return this.http.get(`${this.configUrl}/dbController`).pipe(
      map((res) => {
          this.highscores = res[0];
          // this.highscores = res['data'];
          return this.highscores;
        }
      ),
      catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    console.log(error);
    return throwError('Error! Iets ging fout');

  }
}
