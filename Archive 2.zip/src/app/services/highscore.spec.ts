import { Highscore } from '../entities/highscore';

describe('Highscore', () => {
  it('should create an instance', () => {
    expect(new Highscore()).toBeTruthy();
  });
});
