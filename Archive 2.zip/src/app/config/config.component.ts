import {Component, OnInit} from '@angular/core';
import {ConfigService} from '../services/config.service';
import { Highscore } from '../entities/highscore';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css']
})
export class ConfigComponent implements OnInit {

  highscores: Highscore[];
  error: '';
  succes: '';

  constructor(private configService: ConfigService) {
  }

  ngOnInit(): void {
    this.getScores();
  }

  getScores(): void {
    this.configService.getAll().subscribe(
      (res: Highscore[]) => {
        this.highscores = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }
}
