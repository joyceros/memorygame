import {Component} from '@angular/core';
import {HighscoreService} from '../services/highscore.service';
import { Highscore } from '../entities/highscore';

@Component({
  selector: 'app-highscores',
  templateUrl: './highscores.component.html',
  styleUrls: ['./highscores.component.css']
})
export class HighscoresComponent {

  public list = Highscore[0];

  constructor(private highscoreService: HighscoreService) {
    this.list = this.highscoreService.getHighscores();
  }
}
