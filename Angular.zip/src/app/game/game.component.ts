import {Component, OnInit, ViewChild} from '@angular/core';
import {Card} from '../entities/card';
import {TimerComponent} from '../timer/timer.component';
import {HighscoreService} from '../services/highscore.service';
import {GameService} from '../services/game.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {
  @ViewChild(TimerComponent) timer: TimerComponent;

  public showGame: boolean;
  public selectedCard: Card;
  public currentMessage: string;
  public showWarning = false;
  public routerLink = '';
  private cards = [];
  private currentplayer: string;
  private card1 = new Card('', '');
  private card2 = new Card('', '');
  private timeToTurn = true;

  constructor(private highscoreService: HighscoreService, private gameService: GameService, private router: Router) {
  }

  get cardsList() {
    return this.cards;
  }

  get checkIfDone() {
    for (const i of this.cards) {
      if (i.done === false) {
        return false;
      }
    }
    return true;
  }

  get score() {
    let good = 0;
    for (const i of this.cards) {
      if (i.done === true) {
        good += 1;
      }
    }
    return good + this.timer.timeLeft;
  }

  toggleShowWarning(link): void {
    if (link !== '') {
      this.routerLink = link;
    }
    this.showWarning = !this.showWarning;
  }

  addScore() {
    this.highscoreService.addHighscore(this.currentplayer, this.score);
  }

  showTimesUpMessage() {
    if (!this.checkIfDone) {
      this.currentMessage = 'timesup';
    }
  }

  onSelect(card: Card): void { // when a card is selected either it is the first card clicked or the second
    if (this.timeToTurn && card.show === false) {
      if (this.card1.desc === '') {
        this.firstCardClicked(card);
      } else {
        this.secondCardClicked(card);
      }
    }
  }

  firstCardClicked(card): void { // if the first card has been clicked save the information of this card
    this.card1 = card;
    card.show = true;
    card.done = true;
  }

  secondCardClicked(card): void { // if the second card has been clicked, compare this to the first card.
    this.card2 = card;
    card.show = true;
    const index = this.getIndex(this.card1.name);
    if (this.card1.desc === this.card2.desc) {        // if these cards have the same description
      this.correctAnswer(card, index);
    } else {                                         // if these cards don't have the same description
      this.wrongAnswer(card, index);
    }
    this.emptyCardValues();
  }

  correctAnswer(card, index): void { // if a correct answer has been given, save these as done and check if all cards are done. If so, stop the timer.
    card.done = true;
    this.cards[index].done = true;
    this.currentMessage = 'good';
    if (this.checkIfDone) {
      this.timer.stopTimer();
    }
  }

  wrongAnswer(card, index): void { // if a wrong answer has been given, turn the cards after given time.
    this.cards[index].done = false;
    card.done = false;
    this.currentMessage = 'wrong';
    this.timeToTurn = false; // until the cards are turned this variable disables the function to turn the card.
    setTimeout(() => {
      this.cards[index].show = false;
      card.show = false;
      this.timeToTurn = true;
    }, 1000);
  }

  emptyCardValues(): void {
    this.card1 = new Card('', '');
    this.card2 = new Card('', '');
  }

  getIndex(name) { // get the index of the given name in the cards list.
    for (let i = 0; i < this.cards.length; i++) {
      if (this.cards[i].name === name) {
        return i;
      }
    }
  }

  ngOnInit(): void { // onInit see if there is a playername given, else go back to start. If it is good get the cards from the DB and when the cards are returned setup these cards.
    this.currentplayer = this.gameService.Player;
    if (this.currentplayer === '' || this.currentplayer === undefined) {
      this.router.navigateByUrl('/nieuwproject/start');
    } else {
      this.showGame = true;
      this.gameService.getCardsFromDB().subscribe(cards => {
        this.gameService.selectCards(cards);
        this.cards = this.gameService.cards;
      });
    }
  }
}
