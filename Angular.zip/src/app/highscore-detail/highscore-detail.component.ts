import {Component} from '@angular/core';
import {Highscore} from '../entities/highscore';
import {HighscoreService} from '../services/highscore.service';

@Component({
  selector: 'app-highscore-detail',
  templateUrl: './highscore-detail.component.html',
  styleUrls: ['./highscore-detail.component.css']
})
export class HighscoreDetailComponent {
  public name = '';
  public list: Highscore[];

  constructor(private highscoreService: HighscoreService) {
  }

  setTopThreescores(name) {
    this.name = name;
    this.highscoreService.getHighscoresByName(name).subscribe(list => this.list = list);
  }
}
