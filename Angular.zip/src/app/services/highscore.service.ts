import {Injectable} from '@angular/core';
import {Highscore} from '../entities/highscore';
import {Observable} from 'rxjs';
import {HttpClient, HttpParams} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HighscoreService {

  constructor(private http: HttpClient) {
  }

  addHighscore(id, score) {
    this.addHighscoreToDB(id, score).subscribe();
  }

  // when subscribing to one of the below observable a call is made to db and returns the outcome value

  getHighscores(): Observable<Highscore[]> {
    return this.http.get<Highscore[]>('https://joycerosenau.nl/include/model/gethighscores.php');
  }

  getAlphabeticHighscores(): Observable<Highscore[]> {
    return this.http.get<Highscore[]>('https://joycerosenau.nl/include/model/getalfphabetichighscores.php');
  }

  getHighscoresByName(name): Observable<Highscore[]> {
    const params = new HttpParams().set('name', name);
    return this.http.get<Highscore[]>('https://joycerosenau.nl/include/model/gethighscorebyname.php', {params});
  }

  addHighscoreToDB(id1, id2): Observable<Highscore> {
    const id0 = 0;
    const score = new Highscore(id0, id1, id2);
    return this.http.post<Highscore>('https://joycerosenau.nl/include/model/addscore.php', {data: score});
  }
}
