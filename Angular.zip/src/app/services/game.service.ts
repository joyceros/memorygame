import {Injectable} from '@angular/core';
import {Card} from '../entities/card';
import {Observable} from 'rxjs';
import {HttpClient, HttpParams} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  public cards = [];
  private mockedCards = [];
  private rangeCards = [];
  private allCards: Card[];
  private numbersDone = [];
  private playCards = 8;
  private cardsLength = 52;
  private player = '';

  constructor(private http: HttpClient) {
  }

  get Player() {
    return this.player;
  }

  selectCards(cards) { // get a random number of cards where the number is not too high or too low
    this.cards = [];
    this.mockedCards = [];
    this.rangeCards = [];
    this.numbersDone = [];
    this.allCards = cards;

    let lastCard = Math.floor(Math.random() * this.cardsLength) + this.playCards;
    while (lastCard > this.cardsLength || lastCard % 2 === 1 || lastCard < this.playCards) {
      lastCard = Math.floor(Math.random() * (this.cardsLength)) + this.playCards;
    }
    const s = lastCard - this.playCards;
    this.getRangeCards(s, lastCard);
  }

  getRangeCards(s, l) { // get the range of cards between the given parameters.
    for (let i = 0; i < this.allCards.length; i++) {
      if (i >= s && i < l) {
        this.rangeCards.push(new Card(this.allCards[i].name, this.allCards[i].desc));
      }
    }
    this.shuffle(this.setUpCards(this.rangeCards));
  }

  setUpCards(data) { // add all the data in the form of Cards to a list
    for (let i = 0; i < this.playCards; i++) {
      this.mockedCards.push(new Card(data[i].name, data[i].desc));
    }
    return this.mockedCards;
  }

  shuffle(array) { // shuffle the list of cards for every card. keep track of every index that has already been filled (numbersDone)
    for (let x = 0; x < this.playCards; x++) {
      let random = Math.floor(Math.random() * array.length);
      while (this.numbersDone.includes(random)) {
        random = Math.floor(Math.random() * array.length);
      }
      this.numbersDone.push(random);
      this.cards.push(array[random]);
    }
  }

  setPlayer(player) {
    this.player = player;
  }

  getCardsFromDB(): Observable<Card[]> { // when subscribed to this observable a list of Cards is returned.
    const params = new HttpParams().set('functionname', 'get');
    // return this.http.get<any>('http://memory.local/include/model/getdata.php', {params});
    return this.http.get<any>('https://joycerosenau.nl/include/model/getdata.php', {params});

  }
}
