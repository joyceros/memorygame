import {Component, ViewChild} from '@angular/core';
import {Highscore} from '../entities/highscore';
import {HighscoreService} from '../services/highscore.service';
import {HighscoreDetailComponent} from '../highscore-detail/highscore-detail.component';

@Component({
  selector: 'app-highscores',
  templateUrl: './highscores.component.html',
  styleUrls: ['./highscores.component.css']
})
export class HighscoresComponent {
  @ViewChild(HighscoreDetailComponent) hsDetailComponent: HighscoreDetailComponent;

  public list: Highscore[];
  public ascList: Highscore[];
  public selectedHighscore: string;
  public filterArgs = '';

  constructor(private highscoreService: HighscoreService) { // get a list of highscores from DB
    this.highscoreService.getHighscores().subscribe(list => this.list = list);
    this.highscoreService.getAlphabeticHighscores().subscribe(list => this.ascList = list);
  }

  onSelect(highscore): void { // when a Highscore in the list is selected setup the top three scores of that selectedHighscore
    this.selectedHighscore = highscore.name;
    this.hsDetailComponent.setTopThreescores(this.selectedHighscore);
  }
}
