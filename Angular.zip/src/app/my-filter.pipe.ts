import {Pipe, PipeTransform} from '@angular/core';

import {Highscore} from './entities/highscore';

@Pipe({
  name: 'myFilter',
  pure: false
})
export class MyFilterPipe implements PipeTransform {
  transform(items: Highscore[], filter: string): any { // transform the given parameters to return a list of items.
    if (!items || !filter) { // if there is no given list or filter return empty items
      return items;
    }
    // filter the items, if the name contains the filter it is added to the return list, else it is not.
    return items.filter(item => item.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }
}
