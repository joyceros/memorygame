export class Card {
  name: string;
  desc: string;
  imgSrc: string;
  done: boolean;
  show: boolean;

  constructor(name: string, desc: string) {
    this.name = name;
    this.desc = desc;
    this.imgSrc = 'nieuwproject/assets/' + name + '.jpg';
    this.done = false;
    this.show = false;
  }
}
