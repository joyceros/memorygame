export class Highscore {
  rank: number;
  name: string;
  score: number;

  constructor(rank: number, name: string, score: number) {
    this.rank = rank;
    this.name = name;
    this.score = score;
  }
}
