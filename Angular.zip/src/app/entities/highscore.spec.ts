import {Highscore} from './highscore';

describe('Highscore', () => {
  it('should create an instance', () => {
    expect(new Highscore()).toBeTruthy();
  });
});
