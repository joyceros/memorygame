import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {AppComponent} from './app.component';
import {CardComponent} from './card/card.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {TimerComponent} from './timer/timer.component';
import {HighscoresComponent} from './highscores/highscores.component';
import {HttpClientModule} from '@angular/common/http';
import {GameComponent} from './game/game.component';
import {StartComponent} from './start/start.component';
import {HighscoreDetailComponent} from './highscore-detail/highscore-detail.component';
import {MyFilterPipe} from './my-filter.pipe';

const appRoutes: Routes = [
  {path: 'nieuwproject/start', component: StartComponent},
  {path: 'nieuwproject/game', component: GameComponent},
  {path: 'nieuwproject/scores', component: HighscoresComponent},
  {path: '', redirectTo: '/nieuwproject/start', pathMatch: 'full'},
  {path: '**', component: StartComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    TimerComponent,
    HighscoresComponent,
    GameComponent,
    StartComponent,
    HighscoreDetailComponent,
    MyFilterPipe
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(
      appRoutes
    ),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
