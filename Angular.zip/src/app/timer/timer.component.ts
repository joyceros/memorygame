import {Component, EventEmitter, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {

  @Output() timerStopped = new EventEmitter(); // when timer is stopped, emit this to the listening component (gameComponent)
  timeLeft = 30;
  private interval: any;

  ngOnInit(): void {
    this.startTimer();
  }

  startTimer(): void { // timer has set interval that after every 1 second the timeLeft variable goes down until it is 0 or stopped by stopTimer()
    this.interval = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
      } else {
        this.stopTimer();
      }
    }, 1000);
  }

  stopTimer(): void {
    clearInterval(this.interval);
    this.timerStopped.emit();
  }

}
